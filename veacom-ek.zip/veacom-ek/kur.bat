@echo off
rem VEAcom - yazilimla cizim eki.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur.ps1"
pause
