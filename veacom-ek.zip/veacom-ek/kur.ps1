# VEAcom - yazilimla cizim eki.
#
# Ekran karti goruntuleri cizmeye yetmeyen bilgisayarlar icin (uzak masaustu, eski ekran
# karti, ekran karti surucusu olmayan bilgisayar): VTK OpenGL 3.2 ister, bunlar daha azini
# verir. Mesa'nin yazilimla cizen OpenGL'i (llvmpipe; opengl32.dll + libgallium_wgl.dll)
# VEAcom.exe'nin yanina konur: Windows uygulamanin klasorundeki opengl32.dll'i kendisininkinden
# once yukler. Guncellemede bu dosyalar yerinde kalir.
# GALLIUM_DRIVER=llvmpipe: Mesa Direct3D 12 yolunu denemesin (onun dosyalari ekte yok;
# denendiginde VEAcom kapaniyordu). 1.2.1'den sonraki VEAcom bunu kendisi secer.
param([string]$Folder = "$env:LOCALAPPDATA\Programs\VEAcom")

if (-not (Test-Path "$Folder\VEAcom.exe")) {
    Write-Host "VEAcom bulunamadi: $Folder. Once VEAcom kurulumunu yapin."
    exit 1
}
if (Get-Process VEAcom -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$Folder\*" }) {
    Write-Host "VEAcom acik. Kapatip yeniden calistirin."
    exit 1
}
try {
    foreach ($name in "opengl32.dll", "libgallium_wgl.dll") {
        Copy-Item -Path (Join-Path $PSScriptRoot $name) -Destination "$Folder\$name" -Force
    }
    [Environment]::SetEnvironmentVariable("GALLIUM_DRIVER", "llvmpipe", "User")
    Write-Host "Tamam. VEAcom artik goruntuleri ekran karti olmadan cizer."
} catch {
    Write-Host ("Hata: " + $_.Exception.Message)
    exit 1
}
